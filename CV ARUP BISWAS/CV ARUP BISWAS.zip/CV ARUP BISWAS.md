﻿ARUP BISWAS ![](Aspose.Words.57796b5e-504e-4850-b9f3-59e64c92c187.001.png)![](Aspose.Words.57796b5e-504e-4850-b9f3-59e64c92c187.002.png)![ref1]

BTech in Computer Science and Engineering Indian Institute of Technology Tirupati, India www.linkedin.com/in/arup-biswas-279a06264/ https://github.com/Aeromaster213 

Education Details![](Aspose.Words.57796b5e-504e-4850-b9f3-59e64c92c187.004.png)![](Aspose.Words.57796b5e-504e-4850-b9f3-59e64c92c187.005.png)

Program Institute Year %/CGPA ![](Aspose.Words.57796b5e-504e-4850-b9f3-59e64c92c187.006.png)B.Tech - CSE IIT Tirupati 2025\* 7.2/10 CBSE 12th M.E.S. Indian School, Doha, Qatar 2021 97.2% CBSE 10th M.E.S. Indian School, Doha, Qatar 2019 96.4%

* Program completion in Aug 2025 ![](Aspose.Words.57796b5e-504e-4850-b9f3-59e64c92c187.007.png)Known Languages
- Proficient in English, Conversational  and Written Hindi, Conversational and Written Bengali

Areas of Interest![ref2]

- Website Development, Web Scraping, User Interface Design Technical Proficiency![](Aspose.Words.57796b5e-504e-4850-b9f3-59e64c92c187.009.png)

Operating Systems : Windows, Arch Linux, Fedora

Hardware Platforms : ARM v7, x86 64![](Aspose.Words.57796b5e-504e-4850-b9f3-59e64c92c187.010.png)

Programming Languages : C/C++, Java, Javascript, Python, Verilog

Softwares/Frameworks : Git, CLion, ModelSim, Figma, Notion, Kdenlive, GIMP

Projects![](Aspose.Words.57796b5e-504e-4850-b9f3-59e64c92c187.011.png)

- Tower of Babble -Course Project [September 2023 - November 2023]

Web app to allow transcription and translation of Audio-visual input to text/srt files using AI based models of Whisper.cpp.Docker-ised to allow hosting on your own servDiders. documentation and technology research

of existing solutions.

- Oceanview Android App -Course Project [August 2023 - September 2023]

App showcasing human interactions with the ore ec alanm:ation, oil-spill, plastic disposal, over-fishing, ship-

wreck, and coral reef damaWgerit.ten in React Native, it shows viewers a map screen with the Google Maps API. When a pin is clickedit, then opens up a video display that holds a (rendered) video and an info-card about that pinned locatioWn.as responsible for the video display and rendered video.

- Creating an automated reddit comment bot -Personal Project [July 2023] Using Reddit’s API’s, I am desiging a reddit bot that replies to instances of specific phrases with pop culture reference related to that particular fandP olamn .ning to host it on Repl.it.
- Dart Interpreter in Python -Course Project [Nov 2022 - Dec 2022] Designed an interpreter for a subset of the language Dart in PyI h the olp ne .d in implementing the Abstract

Syntax Trees and did the documentatioOunr. interpreter implemented basic arithmif-eteiclse, conditionals

statements.

- GUI Chess Game -Course Project [May 2022 - Jun 2022] I was part of a team of five in developing a GUI chess game written in PI  yh tehlpone .d design and test the GUI. It implemented most of the moves of modern chess and was designed to be user friendly.
- Designing a 24-Hour Digital Clock in LogiSim -Course Project [Nov 2022 - Dec 2022] ![ref1]Designed a 24-hour format digital clock to display Hours, Minutes, and Seconds and allowed it to sync to real

time and speed up or slow down using vsim tools, implementing a 7-seg-display, counters, in LogiSim.

Relevant Courses![](Aspose.Words.57796b5e-504e-4850-b9f3-59e64c92c187.012.png)

- Data Structures and Algorithms *•* Computer Organisation
- Theory of Computation *•* Discrete Mathematics for Computer Science
- Programming Methodology *•* Digital Systems
- Linear Algebra *•* Probability and Statistics
- Operating Systems\* *•* Machine Learning\*
- Software Engineering\* *•* Compiler Design\*
- Design and Analysis of Algorithms\*
* To be completed in November 2023 Achievements![](Aspose.Words.57796b5e-504e-4850-b9f3-59e64c92c187.013.png)
- Institution of Engineers (India) awardee in 2022 for performance in CBSE, competitive exams, and project works.
- Qatar contingent member for International Chemistry Olympiad (ICHO) in 2021, Japan.
- Top five in Qatar in International Olympiads of Mathematics, Science, and Informatics, by Silver- Zone Foundation from 2013 to 2019.
- Beaver Supermoon and Geminid Meteor Shower Amateur Astrophotography contest Science India Forum-Qatar 2017 winner.
- 23rd National Children’s Science Congress 2015, Chandigarh Qatar representative for my year-long project of co-location of Solar Panels and Aloe-Vera cultivation.
- Sastra Pratibha winner 2014 and bronze medalist 2015.

Positions of Responsibility![](Aspose.Words.57796b5e-504e-4850-b9f3-59e64c92c187.014.png)

Co-ordinator, Quiz Club IIT Tirupati [Aug 2022 - till date]

Quiz master Intra-IIT Culturals 2022, Tirutsava 2Qu023iz.zes creatorR.epresented the institute in Inter-IIT Culturals 2022, IIT Madras and Nihilanth 2023 Inter-IIT-IIM quizzes, IIM Ahmedabad.

Team Leader, Inter IIT Tech Meet 2023, Paradime UI Design [Jan 2023 - Feb 2023]

Led a team of four in low-prep Paradime IDE UI/UX design eP vit ec nh te.d idea to improve existing Paradime IDE to incorporate community-built plugshins,owcasing it to users and included contextual help for general icons.

Team Leader, RC Escapade, Tirutsava 2023 [Mar 2023 - April 2023]

Lead team of five for radio-controlled car racing compBetu itiltio  na  .custom RC Car, helped in designing the racetrack and placed third in the event.

Extra Curricular activities![ref2]

- Bicycling
- Basketball
- National Social Service volunteer.

Hobbies and Interests![](Aspose.Words.57796b5e-504e-4850-b9f3-59e64c92c187.015.png)

- Dabbling in Internet Pop culture.
- Reading story-rich Asian graphic novels.
- Playing role-playing lore-heavy games made by Indie Developers.
Updated on 11/08/2023 2

[ref1]: Aspose.Words.57796b5e-504e-4850-b9f3-59e64c92c187.003.png
[ref2]: Aspose.Words.57796b5e-504e-4850-b9f3-59e64c92c187.008.png
